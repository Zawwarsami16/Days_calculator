package days;

public class Weekdays {
    public void nameOfDay(Day day) {
        System.out.println(day.getDayName());
    }
}
